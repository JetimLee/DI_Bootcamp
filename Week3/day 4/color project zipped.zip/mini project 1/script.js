const body = document.getElementsByTagName("body")[0];

const clearButton = document.getElementsByTagName("button")[0];
const colorSelector = document.getElementById("colorSelector");

const colorGrid = document.querySelector(".grid2");

const parentContainer = document.querySelector(".parentContainer");

parentContainer.addEventListener("click", () => {});
let holdColor;

//creating the empty boxes
for (let i = 0; i < 2418; i++) {
  let coloringBoxes = document.createElement("div");
  coloringBoxes.classList.add("blankBox");
  colorGrid.appendChild(coloringBoxes);
  coloringBoxes.style.backgroundColor = "white";
  coloringBoxes.addEventListener("click", (e) => {
    e.stopPropagation();
    e.target.style.backgroundColor = holdColor;
  });
}

const colorTheBoxes = () => {
  coloringBoxes;
};

const reset = () => {
  for (blank of colorGrid.children) {
    blank.style.backgroundColor = "white";
  }
  console.log("switched");
};

let colors = colorSelector.children;

const colorClick = (arr) => {
  for (let i = 0; i < arr.length; i++) {
    arr[i].addEventListener("click", (e) => {
      let bg = e.target.style.backgroundColor;
      console.log(bg);
      console.log(e.target.style);
      holdColor = bg;
    });
  }
};

colorClick(colors);

clearButton.addEventListener("click", reset);
