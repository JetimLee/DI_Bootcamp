const searchButton = document.getElementById("searchBtn");
console.log(searchButton);
const root = document.getElementById("root");
const searchField = document.getElementById("searchBar");
const loadUserInput = () => {
  let request;
  const searchFieldValue = document.getElementById("searchBar").value;
  let api = `https://api.giphy.com/v1/gifs/search?q=${searchFieldValue}&rating=g&limit=10&api_key=hpvZycW22qCjn5cRM1xtWB8NKq4dQ2My`;
  request = new XMLHttpRequest();
  request.open("GET", api, true);
  request.onload = (data) => {
    let actualData = data.target.response;
    createAGiph(actualData);
  };
  request.send();
};
const createAGiph = (response) => {
  response = JSON.parse(response);
  let gifs = response.data;
  let imageContainer = document.createElement(`div`);
  imageContainer.classList.add("imageContainer");
  root.append(imageContainer);
  let gifImage = document.createElement("img");
  imageContainer.append(gifImage);
  let imagesSources = gifs.map((el) => {
    gifImage.src = el.bitly_gif_url;
  });
  return imagesSources;
};
searchButton.addEventListener("click", loadUserInput);
